const fetch = require("node-fetch");

exports.handler = async () => {
  const baseId = process.env.AIRTABLE_BASE_ID;
  const apiKey = process.env.AIRTABLE_API_KEY;
  const url = `https://api.airtable.com/v0/${baseId}/Dates`;

  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${apiKey}` }
  });

  const data = await response.json();
  return {
    statusCode: 200,
    body: JSON.stringify(data.records)
  };
};
